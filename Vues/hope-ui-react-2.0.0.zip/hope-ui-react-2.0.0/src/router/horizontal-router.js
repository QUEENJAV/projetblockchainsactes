import React from 'react'
import Index from '../views/dashboard/index'
const HorizontalRouter = () => {
    return (
        <div>
            <Index />
        </div>
    )
}

export default HorizontalRouter

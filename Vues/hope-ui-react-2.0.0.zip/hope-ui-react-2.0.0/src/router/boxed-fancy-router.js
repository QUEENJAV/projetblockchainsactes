import React from 'react'
import Index from '../views/dashboard/index'
const BoxedFancyRouter = () => {
    return (
        <div>
            <Index />
        </div>
    )
}

export default BoxedFancyRouter

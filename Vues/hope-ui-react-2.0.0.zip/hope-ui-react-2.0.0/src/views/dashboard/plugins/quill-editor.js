import React from 'react'

const QuillEditor = () => {
    return (
        <div>
            
        </div>
    )
}

export default QuillEditor

import React from 'react'

const NoUiSlider = () => {
    return (
        <div>
            
        </div>
    )
}

export default NoUiSlider

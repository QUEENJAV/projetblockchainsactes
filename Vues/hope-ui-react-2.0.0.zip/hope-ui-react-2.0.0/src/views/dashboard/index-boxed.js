import React from 'react'
import BoxedFancy from './index-boxed-fancy'

const Boxed = () => {
 
    return (
        <div>
            Boxed
            <BoxedFancy ></BoxedFancy>
        </div>
    )
}

export default Boxed

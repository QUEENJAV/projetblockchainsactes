import React from 'react'

const CounterUps = () => {
    return (
        <>
            <h2 className="counter">$6563756358</h2>
        </>
    )
}

export default CounterUps